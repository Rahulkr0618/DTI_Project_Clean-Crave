package com.example.dti_project;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class KathiAdminFoodHistoryAdapter extends RecyclerView.Adapter<KathiAdminFoodHistoryAdapter.ViewHolder> {

    private List<kathiadminfoodhistorymodel> orderList;
    private List<kathiadminfoodhistorymodel> filteredOrderList;

    public KathiAdminFoodHistoryAdapter(List<kathiadminfoodhistorymodel> orderList) {
        this.orderList = orderList;
        this.filteredOrderList = new ArrayList<>(orderList);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerowfoodhistorykathiadmin, parent, false);
        return new ViewHolder(view, this); // Pass the adapter instance
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        kathiadminfoodhistorymodel order = filteredOrderList.get(position);
        holder.bind(order);
    }

    @Override
    public int getItemCount() {
        return filteredOrderList.size();
    }

    public void filterList(List<kathiadminfoodhistorymodel> filteredList) {
        filteredOrderList = filteredList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView enrollNoTextView, timeTextView, dateTextView, confirmOrderTextView, orderDetailsTextView, totalTextView;
        kathiadminfoodhistorymodel order;
        KathiAdminFoodHistoryAdapter adapter;

        public ViewHolder(@NonNull View itemView, KathiAdminFoodHistoryAdapter adapter) {
            super(itemView);
            enrollNoTextView = itemView.findViewById(R.id.kathiadminfoodviewhistoryEnrollNo);
            timeTextView = itemView.findViewById(R.id.kathiadminfoodviewhistorytime);
            dateTextView = itemView.findViewById(R.id.kathiadminfoodviewhistorydate);
            confirmOrderTextView = itemView.findViewById(R.id.kathiadminfoodviewhistoryconfirm);
            orderDetailsTextView = itemView.findViewById(R.id.kathiadminorderitems);
            totalTextView = itemView.findViewById(R.id.kathiadminfoodviewhistorytotal);

            this.adapter = adapter; // Assign the adapter instance

            // Set click listener for the confirmfoodorderbutton
            ImageButton confirmButton = itemView.findViewById(R.id.confirmfoodorderbutton);
            confirmButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showConfirmationDialog(); // Pass the order object here
                }
            });
        }

        public void bind(kathiadminfoodhistorymodel order) {
            this.order = order; // Set the order object
            enrollNoTextView.setText(order.getEnrollNo());
            timeTextView.setText(order.getTime());
            dateTextView.setText(order.getDate());
            confirmOrderTextView.setText(order.getConfirmOrder());
            // Set order details
            StringBuilder orderDetailsText = new StringBuilder();
            List<String> orderDetailsList = order.getOrderDetails();
            for (String item : orderDetailsList) {
                orderDetailsText.append(item).append("\n");
            }
            orderDetailsTextView.setText(orderDetailsText.toString());

            totalTextView.setText(String.valueOf(order.getTotal()));
        }

        private void showConfirmationDialog() {
            AlertDialog.Builder builder = new AlertDialog.Builder(itemView.getContext());
            builder.setTitle("Confirm Order");
            builder.setMessage("Confirm this order?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    // Update ConfirmOrder field to "yes" in Firestore
                    updateConfirmationInFirestore();
                }
            });
            builder.setNegativeButton("No", null);
            builder.show();
        }

        private void updateConfirmationInFirestore() {

            String orderId = order.getCustomPKKathiUser();

            FirebaseFirestore.getInstance().collection("KathiFoodOrder")
                    .document(orderId)
                    .update("ConfirmOrder", "yes")
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(itemView.getContext(), "Order confirmed", Toast.LENGTH_SHORT).show();

                            adapter.notifyDataSetChanged();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e(TAG, "Error updating order confirmation", e);
                            Toast.makeText(itemView.getContext(), "Failed to confirm order", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }
}
