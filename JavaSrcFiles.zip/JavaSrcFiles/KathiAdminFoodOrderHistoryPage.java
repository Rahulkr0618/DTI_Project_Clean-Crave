package com.example.dti_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.CheckBox;
import android.widget.EditText;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;

public class KathiAdminFoodOrderHistoryPage extends AppCompatActivity {

    RecyclerView kathifoodhistoryrecview;
    KathiAdminFoodHistoryAdapter adapter;
    List<kathiadminfoodhistorymodel> orderList;
    FirebaseFirestore firestore;
    CheckBox confirmedCheckBox;

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, KathiAdminPage.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kathi_admin_food_order_history_page);

        kathifoodhistoryrecview = findViewById(R.id.kathifoodhistoryrecview);
        kathifoodhistoryrecview.setLayoutManager(new LinearLayoutManager(this));

        orderList = new ArrayList<>();
        adapter = new KathiAdminFoodHistoryAdapter(orderList);
        kathifoodhistoryrecview.setAdapter(adapter);

        confirmedCheckBox = findViewById(R.id.kathifoodhistoryCBConfirmed);
        firestore = FirebaseFirestore.getInstance();

        firestore.collection("KathiFoodOrder")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        orderList.clear(); // Clear the list before adding new data
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            kathiadminfoodhistorymodel order = document.toObject(kathiadminfoodhistorymodel.class);
                            orderList.add(order);
                        }
                        adapter.notifyDataSetChanged();

                        filterOrders();
                    }
                });

        EditText enrollNoEditText = findViewById(R.id.kathifoodhistooryEnrollno);
        EditText dateEditText = findViewById(R.id.kathifoodhistoryDate);

        // Add text change listeners to EditText fields for searching
        enrollNoEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filterOrders();
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        dateEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filterOrders();
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        // Add listener to the checkbox for filtering orders
        confirmedCheckBox.setOnCheckedChangeListener((compoundButton, isChecked) -> filterOrders());
    }

    private void filterOrders() {
        String enrollNo = ((EditText) findViewById(R.id.kathifoodhistooryEnrollno)).getText().toString().trim();
        String date = ((EditText) findViewById(R.id.kathifoodhistoryDate)).getText().toString().trim();
        boolean confirmed = confirmedCheckBox.isChecked();

        List<kathiadminfoodhistorymodel> filteredList = new ArrayList<>();

        for (kathiadminfoodhistorymodel order : orderList) {
            if ((TextUtils.isEmpty(enrollNo) || order.getEnrollNo().contains(enrollNo)) &&
                    (TextUtils.isEmpty(date) || order.getDate().contains(date))) {
                if (confirmed && order.getConfirmOrder().equalsIgnoreCase("yes")) {
                    filteredList.add(order);
                } else if (!confirmed && order.getConfirmOrder().equalsIgnoreCase("no")) {
                    filteredList.add(order);
                }
            }
        }

        // Sort the filtered list by date in descending order (latest first)
        Collections.sort(filteredList, new Comparator<kathiadminfoodhistorymodel>() {
            @Override
            public int compare(kathiadminfoodhistorymodel o1, kathiadminfoodhistorymodel o2) {
                return o2.getDate().compareTo(o1.getDate());
            }
        });

        adapter.filterList(filteredList);
    }
}
