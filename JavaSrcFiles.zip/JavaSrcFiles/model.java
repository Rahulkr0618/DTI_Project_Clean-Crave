package com.example.dti_project;

public class model {

    String customPrimaryKey;
    String laundryEnrollNo, laundryBagNo,laundryDate,laundryKurta,laundryPajama,laundryShirt,laundryTshirt,laundryPant,laundryLower,laundryShorts,laundryBedsheet,laundryPillowCov,laundryTowel,laundryDuppata,laundryTotal,confirmation,time;

    model(){

    }

    public model(String customPrimaryKey,String laundryEnrollNo, String laundryBagNo, String laundryDate, String laundryKurta, String laundryPajama, String laundryShirt, String laundryTshirt, String laundryPant, String laundryLower, String laundryShorts, String laundryBedsheet, String laundryPillowCov, String laundryTowel, String laundryDuppata, String laundryTotal, String confirmation, String time) {
        this.customPrimaryKey = customPrimaryKey;
        this.laundryEnrollNo = laundryEnrollNo;
        this.laundryBagNo = laundryBagNo;
        this.laundryDate = laundryDate;
        this.laundryKurta = laundryKurta;
        this.laundryPajama = laundryPajama;
        this.laundryShirt = laundryShirt;
        this.laundryTshirt = laundryTshirt;
        this.laundryPant = laundryPant;
        this.laundryLower = laundryLower;
        this.laundryShorts = laundryShorts;
        this.laundryBedsheet = laundryBedsheet;
        this.laundryPillowCov = laundryPillowCov;
        this.laundryTowel = laundryTowel;
        this.laundryDuppata = laundryDuppata;
        this.laundryTotal = laundryTotal;
        this.confirmation = confirmation;
        this.time = time;
    }

    public String getCustomPrimaryKey() {
        return customPrimaryKey;
    }

    public void setCustomPrimaryKey(String customPrimaryKey) {
        this.customPrimaryKey = customPrimaryKey;
    }

    public String getLaundryEnrollNo() {
        return laundryEnrollNo;
    }

    public void setLaundryEnrollNo(String laundryEnrollNo) {
        this.laundryEnrollNo = laundryEnrollNo;
    }

    public String getLaundryBagNo() {
        return laundryBagNo;
    }

    public void setLaundryBagNo(String laundryBagNo) {
        this.laundryBagNo = laundryBagNo;
    }

    public String getLaundryDate() {
        return laundryDate;
    }

    public void setLaundryDate(String laundryDate) {
        this.laundryDate = laundryDate;
    }

    public String getLaundryKurta() {
        return laundryKurta;
    }

    public void setLaundryKurta(String laundryKurta) {
        this.laundryKurta = laundryKurta;
    }

    public String getLaundryPajama() {
        return laundryPajama;
    }

    public void setLaundryPajama(String laundryPajama) {
        this.laundryPajama = laundryPajama;
    }

    public String getLaundryShirt() {
        return laundryShirt;
    }

    public void setLaundryShirt(String laundryShirt) {
        this.laundryShirt = laundryShirt;
    }

    public String getLaundryTshirt() {
        return laundryTshirt;
    }

    public void setLaundryTshirt(String laundryTshirt) {
        this.laundryTshirt = laundryTshirt;
    }

    public String getLaundryPant() {
        return laundryPant;
    }

    public void setLaundryPant(String laundryPant) {
        this.laundryPant = laundryPant;
    }

    public String getLaundryLower() {
        return laundryLower;
    }

    public void setLaundryLower(String laundryLower) {
        this.laundryLower = laundryLower;
    }

    public String getLaundryShorts() {
        return laundryShorts;
    }

    public void setLaundryShorts(String laundryShorts) {
        this.laundryShorts = laundryShorts;
    }

    public String getLaundryBedsheet() {
        return laundryBedsheet;
    }

    public void setLaundryBedsheet(String laundryBedsheet) {
        this.laundryBedsheet = laundryBedsheet;
    }

    public String getLaundryPillowCov() {
        return laundryPillowCov;
    }

    public void setLaundryPillowCov(String laundryPillowCov) {
        this.laundryPillowCov = laundryPillowCov;
    }

    public String getLaundryTowel() {
        return laundryTowel;
    }

    public void setLaundryTowel(String laundryTowel) {
        this.laundryTowel = laundryTowel;
    }

    public String getLaundryDuppata() {
        return laundryDuppata;
    }

    public void setLaundryDuppata(String laundryDuppata) {
        this.laundryDuppata = laundryDuppata;
    }

    public String getLaundryTotal() {
        return laundryTotal;
    }

    public void setLaundryTotal(String laundryTotal) {
        this.laundryTotal = laundryTotal;
    }

    public String getConfirmation() {
        return confirmation;
    }

    public void setConfirmation(String confirmation) {
        this.confirmation = confirmation;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
