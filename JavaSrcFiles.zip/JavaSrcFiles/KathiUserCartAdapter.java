package com.example.dti_project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class KathiUserCartAdapter extends ArrayAdapter<KathiUserFoodMenuAdapter.CartItem> {

    private Context mContext;
    private ArrayList<KathiUserFoodMenuAdapter.CartItem> mCartList;

    public KathiUserCartAdapter(Context context, ArrayList<KathiUserFoodMenuAdapter.CartItem> cartList) {
        super(context, 0, cartList);
        mContext = context;
        mCartList = cartList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(mContext).inflate(R.layout.cartitem, parent, false);
        }

        KathiUserFoodMenuAdapter.CartItem cartItem = getItem(position); // Get the cart item

        TextView itemNameView = listItem.findViewById(R.id.item_name);
        TextView itemQuantityView = listItem.findViewById(R.id.item_quantity);
        TextView itemPriceView = listItem.findViewById(R.id.item_price);


        itemNameView.setText(cartItem.itemName); // Set the name in the list item view
        itemQuantityView.setText(String.valueOf(cartItem.quantity));
        itemPriceView.setText(String.valueOf(cartItem.itemPrice)); // Set the price in the list item view

        return listItem;
    }
}
