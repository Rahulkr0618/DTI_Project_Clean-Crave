package com.example.dti_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.Firebase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LaundryLogin extends AppCompatActivity {

    EditText laundryloginEnrollmentNo,laundryloginBagNo;
    Button laundryloginbtn;
    private DatabaseReference laundryLoginRef;


    @Override
    public void onBackPressed() {

        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
        finish();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laundry_login);

        laundryloginEnrollmentNo =findViewById(R.id.laundryloginEnrollmentNo);
        laundryloginBagNo = findViewById(R.id.laundryloginBagNo);
        laundryloginbtn = findViewById(R.id.laundryloginbtn);

        laundryLoginRef = FirebaseDatabase.getInstance().getReference().child("LaundryLoginDetail");

        laundryloginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enrollmentNumber = laundryloginEnrollmentNo.getText().toString().trim();
                String bagNumber = laundryloginBagNo.getText().toString().trim();

                // Check if Enrollment Number and Bag Number are not empty
                if (!enrollmentNumber.isEmpty() && !bagNumber.isEmpty()) {
                    // Check if the provided credentials exist in the LaundryLoginDetail table
                    laundryLoginRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            boolean found = false;
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                String entryEnrollmentNo = snapshot.child("EnrollmentNo").getValue(String.class);
                                String entryBagNo = snapshot.child("BagNo").getValue(String.class);
                                if (enrollmentNumber.equals(entryEnrollmentNo) && bagNumber.equals(entryBagNo)) {
                                    found = true;
                                    break;
                                }
                            }
                            if (found) {
                                // Credentials matched, proceed to the next screen
                                Intent intent = new Intent(LaundryLogin.this, LaundryUserOrderPage.class);
                                intent.putExtra("enrollmentNo", enrollmentNumber);
                                intent.putExtra("bagNo", bagNumber);
                                startActivity(intent);
                                finish();
                            } else {
                                // Display error message if credentials are not found
                                Toast.makeText(LaundryLogin.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            // Handle errors
                            Toast.makeText(LaundryLogin.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    // Display error message if any field is empty
                    Toast.makeText(LaundryLogin.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }
}