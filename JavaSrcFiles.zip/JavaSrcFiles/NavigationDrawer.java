package com.example.dti_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class NavigationDrawer extends AppCompatActivity {

//    DrawerLayout drawerlayout;
//    ImageButton drawerbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_drawer);

//        drawerlayout = findViewById(R.id.drawerLayout);
//        drawerbutton = findViewById(R.id.drawerButton);

//        drawerbutton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                drawerlayout.openDrawer(GravityCompat.START);
//            }
//        });

    }
}