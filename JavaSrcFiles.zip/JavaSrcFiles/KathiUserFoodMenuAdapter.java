package com.example.dti_project;

import android.content.Intent;
import android.icu.text.Transliterator;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.HashMap;

public class KathiUserFoodMenuAdapter extends RecyclerView.Adapter<KathiUserFoodMenuAdapter.myviewholderkathiUserFoodMenu> {

    ArrayList<KathiUserFoodModel> KathiUserFoodList;

    ArrayList<CartItem> userCartList;

    class CartItem {
        String itemName;
        int itemPrice;
        int quantity;

        public CartItem(String itemName, int itemPrice) {
            this.itemName = itemName;
            this.itemPrice = itemPrice;
            this.quantity = 1;
        }
    }

    public KathiUserFoodMenuAdapter(ArrayList<KathiUserFoodModel> kathiUserFoodList) {
        this.KathiUserFoodList = kathiUserFoodList;
        this.userCartList = new ArrayList<>();
    }

    @NonNull
    @Override
    public myviewholderkathiUserFoodMenu onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view2 = LayoutInflater.from(parent.getContext()).inflate(R.layout.kathiuserfoodmenusinglerow, parent, false);
        return new KathiUserFoodMenuAdapter.myviewholderkathiUserFoodMenu(view2);

    }

    @Override
    public void onBindViewHolder(@NonNull myviewholderkathiUserFoodMenu holder, int position) {

        KathiUserFoodModel currentItem = KathiUserFoodList.get(position);

        holder.foodname.setText(currentItem.getName());
        holder.foodprice.setText(currentItem.getPrice());

        Glide.with(holder.foodimg.getContext()).load(currentItem.getImage()).into(holder.foodimg);


        holder.kathiaddfooduserbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String foodName = currentItem.getName();
                int foodPrice = Integer.parseInt(currentItem.getPrice());

                boolean itemExists = false;
                for (CartItem cartItem : userCartList) {
                    if (cartItem.itemName.equals(foodName)) {
                        // Update the price of the existing item
                        cartItem.itemPrice += foodPrice;
                        cartItem.quantity++;
                        itemExists = true;
                        break;
                    }
                }

                if (!itemExists) {
                    userCartList.add(new CartItem(foodName, foodPrice));
                }

                updateListView(holder.itemView.getContext());
            }
        });


        holder.kathiremovefooduserbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String foodName = currentItem.getName();
                int foodPrice = Integer.parseInt(currentItem.getPrice());

                for (CartItem cartItem : userCartList) {
                    if (cartItem.itemName.equals(foodName)) {
                        if (cartItem.quantity == 1) {
                            userCartList.remove(cartItem);
                        } else {

                            cartItem.quantity--;
                            cartItem.itemPrice -= foodPrice;
                        }
                        break;
                    }
                }
                updateListView(holder.itemView.getContext());

            }
        });

    }

    @Override
    public int getItemCount() {
        return KathiUserFoodList.size();
    }

    class myviewholderkathiUserFoodMenu extends RecyclerView.ViewHolder {

        ImageButton kathiaddfooduserbtn,kathiremovefooduserbtn;
        ImageView foodimg;
        TextView foodname, foodprice;

        public myviewholderkathiUserFoodMenu(@NonNull View itemView) {
            super(itemView);


            foodimg = itemView.findViewById(R.id.kathiUser_food_img);
            foodname = itemView.findViewById(R.id.kathiUser_FoodName);
            foodprice = itemView.findViewById(R.id.kathiUser_FoodPrice);
            kathiaddfooduserbtn = itemView.findViewById(R.id.kathiaddfooduserbtn);
            kathiremovefooduserbtn = itemView.findViewById(R.id.kathiremovefooduserbtn);
        }
    }

    private void updateListView(Context context) {
        // You need to implement the logic to update the ListView with userCartList items here
        ListView listviewkathiusercart = ((AppCompatActivity) context).findViewById(R.id.listviewkathiusercart);
        KathiUserCartAdapter adapter = new KathiUserCartAdapter(context, userCartList);
        listviewkathiusercart.setAdapter(adapter);
    }
}