package com.example.dti_project;

public class Kathimodel {

    String Image,Name,PID,Price,Stock,CustomPKKathi;

    public Kathimodel() {

    }

    public Kathimodel(String CustomPKKathi,String image, String name, String PID, String price, String stock) {
        this.CustomPKKathi = CustomPKKathi;
        this.Image = image;
        this.Name = name;
        this.PID = PID;
        this.Price = price;
        this.Stock = stock;
    }


    public String getCustomPKKathi() {
        return CustomPKKathi;
    }

    public void setCustomPKKathi(String customPKKathi) {
        CustomPKKathi = customPKKathi;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        this.Image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getPID() {
        return PID;
    }

    public void setPID(String PID) {
        this.PID = PID;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        this.Price = price;
    }

    public String getStock() {
        return Stock;
    }

    public void setStock(String stock) {
        this.Stock = stock;
    }
}
