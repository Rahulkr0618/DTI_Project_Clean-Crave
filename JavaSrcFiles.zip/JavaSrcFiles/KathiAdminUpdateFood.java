package com.example.dti_project;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class KathiAdminUpdateFood extends AppCompatActivity {

    RecyclerView Kathirecview;
    ArrayList<Kathimodel> kathifoodlist;
    FirebaseFirestore FBFAdmindb;
    KathiAdpaterAdmin kathiadminadapter;


    @Override
    public void onBackPressed() {

        Intent intent = new Intent(this, KathiAdminPage.class);
        startActivity(intent);
        finish();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kathi_admin_update_food);

        Kathirecview = (RecyclerView) findViewById(R.id.Kathi_recview_update);
        Kathirecview.setLayoutManager(new LinearLayoutManager(this));
        kathifoodlist = new ArrayList<>();
        kathiadminadapter = new KathiAdpaterAdmin(kathifoodlist);
        Kathirecview.setAdapter(kathiadminadapter);



        FBFAdmindb = FirebaseFirestore.getInstance();
        FBFAdmindb.collection("FoodMenu").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<DocumentSnapshot> listkathiadminupdatefood = queryDocumentSnapshots.getDocuments();
                        for(DocumentSnapshot d:listkathiadminupdatefood){
                            Kathimodel obj = d.toObject(Kathimodel.class);
                            kathifoodlist.add(obj);
                        }
                        kathiadminadapter.notifyDataSetChanged();
                    }
                }).addOnFailureListener(e -> Log.e(TAG, "Error fetching data: ", e));

    }
}