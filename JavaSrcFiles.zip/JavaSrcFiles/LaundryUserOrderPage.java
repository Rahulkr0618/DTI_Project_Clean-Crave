package com.example.dti_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.HashMap;
import java.util.Map;



public class LaundryUserOrderPage extends AppCompatActivity {

    TextView LaundryUserEnrollmentNo,LaundryUserBagNo,laundryUserDate;
    EditText kurtaEditText, pajamaEditText, shirtEditText, tShirtEditText, pantEditText, lowerEditText, shortsEditText, bedsheetEditText, pillowCoverEditText, towelEditText, duppataEditText,laundryUserTotal;
    Button submitButton;
    FirebaseFirestore db;


    @Override
    public void onBackPressed() {

        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laundry_user_order_page);

        db = FirebaseFirestore.getInstance();

        kurtaEditText = findViewById(R.id.laundryUserKurta);
        pajamaEditText = findViewById(R.id.laundryUserPajama);
        shirtEditText = findViewById(R.id.laundryUserShirt);
        tShirtEditText = findViewById(R.id.laundryUserTShirt);
        pantEditText = findViewById(R.id.laundryUserPant);
        lowerEditText = findViewById(R.id.laundryUserLower);
        shortsEditText = findViewById(R.id.laundryUserShorts);
        bedsheetEditText = findViewById(R.id.laundryUserBedsheet);
        pillowCoverEditText = findViewById(R.id.laundryUserPillowCover);
        towelEditText = findViewById(R.id.laundryUserTowel);
        duppataEditText = findViewById(R.id.laundryUserDuppata);
        submitButton = findViewById(R.id.laundryUserSubmitBtn);
        laundryUserTotal = findViewById(R.id.laundryUserTotal);
        LaundryUserEnrollmentNo = findViewById(R.id.LaundryUserEnrollmentNo);
        LaundryUserBagNo = findViewById(R.id.LaundryUserBagNo);
        laundryUserDate = findViewById(R.id.laundryUserDate);

        String enrollmentNo = getIntent().getStringExtra("enrollmentNo");
        String bagNo = getIntent().getStringExtra("bagNo");

        LaundryUserEnrollmentNo.setText(enrollmentNo);
        LaundryUserBagNo.setText(bagNo);

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        String currentDate = sdf.format(new Date());
        laundryUserDate.setText(currentDate);

        addTextWatchers();


        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String laundryEnrollNo = LaundryUserEnrollmentNo.getText().toString();
                String laundryBagNo = LaundryUserBagNo.getText().toString();
                String laundryDate = laundryUserDate.getText().toString();
                String laundryKurta = kurtaEditText.getText().toString();
                String laundryPajama = pajamaEditText.getText().toString();
                String laundryShirt = shirtEditText.getText().toString();
                String laundryTshirt = tShirtEditText.getText().toString();
                String laundryPant = pantEditText.getText().toString();
                String laundryLower = lowerEditText.getText().toString();
                String laundryShorts = shortsEditText.getText().toString();
                String laundryBedsheet = bedsheetEditText.getText().toString();
                String laundryPillowCov = pillowCoverEditText.getText().toString();
                String laundryTowel = towelEditText.getText().toString();
                String laundryDuppata = duppataEditText.getText().toString();
                String laundryTotal = laundryUserTotal.getText().toString();
                String confirmation = "NotReceived";
                String time = "";

                String key = enrollmentNo + "_" + bagNo + "_" + getCurrentDateTime();

                //Laundry laundry =new Laundry(laundryEnrollNo,laundryBagNo,laundryDate,laundryKurta,laundryPajama,laundryShirt,laundryTshirt,laundryPant,laundryLower,laundryShorts,laundryBedsheet,laundryPillowCov,laundryTowel,laundryDuppata,laundryTotal,confirmation,time);

                Map<String, Object> laundryData = new HashMap<>();
                laundryData.put("customPrimaryKey", key);
                laundryData.put("laundryEnrollNo", laundryEnrollNo);
                laundryData.put("laundryBagNo", laundryBagNo);
                laundryData.put("laundryDate", laundryDate);
                laundryData.put("laundryKurta", laundryKurta);
                laundryData.put("laundryPajama", laundryPajama);
                laundryData.put("laundryShirt", laundryShirt);
                laundryData.put("laundryTshirt", laundryTshirt);
                laundryData.put("laundryPant", laundryPant);
                laundryData.put("laundryLower", laundryLower);
                laundryData.put("laundryShorts", laundryShorts);
                laundryData.put("laundryBedsheet", laundryBedsheet);
                laundryData.put("laundryPillowCov", laundryPillowCov);
                laundryData.put("laundryTowel", laundryTowel);
                laundryData.put("laundryDuppata", laundryDuppata);
                laundryData.put("laundryTotal", laundryTotal);
                laundryData.put("confirmation", confirmation);
                laundryData.put("time", time);

                db.collection("LaundryDetail")
                        .document(key) // Use custom primary key for document reference
                        .set(laundryData) // Set document data
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(LaundryUserOrderPage.this, "Laundry details added successfully", Toast.LENGTH_SHORT).show();
                                    submitButton.setEnabled(false);
                                } else {
                                    Toast.makeText(LaundryUserOrderPage.this, "Failed to add laundry details: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

            }
        });

    }

    private String getCurrentDateTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        return dateFormat.format(calendar.getTime());
    }

    private void addTextWatchers() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void afterTextChanged(Editable editable) {
                // Calculate sum and update laundryUserTotal
                int sum = getEditTextValue(kurtaEditText) + getEditTextValue(pajamaEditText) +
                        getEditTextValue(shirtEditText) + getEditTextValue(tShirtEditText) +
                        getEditTextValue(pantEditText) + getEditTextValue(lowerEditText) +
                        getEditTextValue(shortsEditText) + getEditTextValue(bedsheetEditText) +
                        getEditTextValue(pillowCoverEditText) + getEditTextValue(towelEditText) +
                        getEditTextValue(duppataEditText);

                laundryUserTotal.setText(String.valueOf(sum));

                submitButton.setEnabled(sum <= 10);

                if (sum > 10) {
                    Toast.makeText(LaundryUserOrderPage.this, "Maximum clothes can be 10.", Toast.LENGTH_SHORT).show();
                }
            }
        };

        kurtaEditText.addTextChangedListener(textWatcher);
        pajamaEditText.addTextChangedListener(textWatcher);
        shirtEditText.addTextChangedListener(textWatcher);
        tShirtEditText.addTextChangedListener(textWatcher);
        pantEditText.addTextChangedListener(textWatcher);
        lowerEditText.addTextChangedListener(textWatcher);
        shortsEditText.addTextChangedListener(textWatcher);
        bedsheetEditText.addTextChangedListener(textWatcher);
        pillowCoverEditText.addTextChangedListener(textWatcher);
        towelEditText.addTextChangedListener(textWatcher);
        duppataEditText.addTextChangedListener(textWatcher);
    }
    private int getEditTextValue(EditText editText) {
        String text = editText.getText().toString().trim();
        if (!text.isEmpty()) {
            try {
                return Integer.parseInt(text);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }

    public class Laundry{

        private String laundryEnrollNo;
        private String laundryBagNo;
        private String laundryDate;
        private String laundryKurta;
        private String laundryPajama;
        private String laundryShirt;
        private String laundryTshirt;
        private String laundryPant;
        private String laundryLower;
        private String laundryShorts;
        private String laundryBedsheet;
        private String laundryPillowCov;
        private String laundryTowel;
        private String laundryDuppata;
        private String laundryTotal;
        private String confirmation;
        private String time;

        public Laundry(){

        }

        public Laundry(String laundryEnrollNo,String laundryBagNo,String laundryDate,String laundryKurta,String laundryPajama,String laundryShirt,String laundryTshirt,String laundryPant,String laundryLower,String laundryShorts,String laundryBedsheet,String laundryPillowCov,String laundryTowel,String laundryDuppata,String laundryTotal,String confirmation,String time){

            this.laundryEnrollNo = laundryEnrollNo;
            this.laundryBagNo = laundryBagNo;
            this.laundryDate = laundryDate;
            this.laundryKurta = laundryKurta;
            this.laundryPajama = laundryPajama;
            this.laundryShirt = laundryShirt;
            this.laundryTshirt = laundryTshirt;
            this.laundryPant = laundryPant;
            this.laundryLower = laundryLower;
            this.laundryShorts = laundryShorts;
            this.laundryBedsheet = laundryBedsheet;
            this.laundryPillowCov = laundryPillowCov;
            this.laundryTowel = laundryTowel;
            this.laundryDuppata = laundryDuppata;
            this.laundryTotal = laundryTotal;
            this.confirmation = confirmation;
            this.time = time;


        }

        public String getLaundryEnrollNo() {
            return laundryEnrollNo;
        }

        public void setLaundryEnrollNo(String laundryEnrollNo) {
            this.laundryEnrollNo = laundryEnrollNo;
        }

        public String getLaundryBagNo() {
            return laundryBagNo;
        }

        public void setLaundryBagNo(String laundryBagNo) {
            this.laundryBagNo = laundryBagNo;
        }

        public String getLaundryDate() {
            return laundryDate;
        }

        public void setLaundryDate(String laundryDate) {
            this.laundryDate = laundryDate;
        }

        public String getLaundryKurta() {
            return laundryKurta;
        }

        public void setLaundryKurta(String laundryKurta) {
            this.laundryKurta = laundryKurta;
        }

        public String getLaundryPajama() {
            return laundryPajama;
        }

        public void setLaundryPajama(String laundryPajama) {
            this.laundryPajama = laundryPajama;
        }

        public String getLaundryShirt() {
            return laundryShirt;
        }

        public void setLaundryShirt(String laundryShirt) {
            this.laundryShirt = laundryShirt;
        }

        public String getLaundryTshirt() {
            return laundryTshirt;
        }

        public void setLaundryTshirt(String laundryTshirt) {
            this.laundryTshirt = laundryTshirt;
        }

        public String getLaundryPant() {
            return laundryPant;
        }

        public void setLaundryPant(String laundryPant) {
            this.laundryPant = laundryPant;
        }

        public String getLaundryLower() {
            return laundryLower;
        }

        public void setLaundryLower(String laundryLower) {
            this.laundryLower = laundryLower;
        }

        public String getLaundryShorts() {
            return laundryShorts;
        }

        public void setLaundryShorts(String laundryShorts) {
            this.laundryShorts = laundryShorts;
        }

        public String getLaundryBedsheet() {
            return laundryBedsheet;
        }

        public void setLaundryBedsheet(String laundryBedsheet) {
            this.laundryBedsheet = laundryBedsheet;
        }

        public String getLaundryPillowCov() {
            return laundryPillowCov;
        }

        public void setLaundryPillowCov(String laundryPillowCov) {
            this.laundryPillowCov = laundryPillowCov;
        }

        public String getLaundryTowel() {
            return laundryTowel;
        }

        public void setLaundryTowel(String laundryTowel) {
            this.laundryTowel = laundryTowel;
        }

        public String getLaundryDuppata() {
            return laundryDuppata;
        }

        public void setLaundryDuppata(String laundryDuppata) {
            this.laundryDuppata = laundryDuppata;
        }

        public String getLaundryTotal() {
            return laundryTotal;
        }

        public void setLaundryTotal(String laundryTotal) {
            this.laundryTotal = laundryTotal;
        }

        public String getConfirmation() {
            return confirmation;
        }

        public void setConfirmation(String confirmation) {
            this.confirmation = confirmation;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }
    }

}