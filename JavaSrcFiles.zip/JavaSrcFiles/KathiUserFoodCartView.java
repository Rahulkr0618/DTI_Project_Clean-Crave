package com.example.dti_project;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;

public class KathiUserFoodCartView extends AppCompatActivity {

    private ListView KathiUserFoodListViewx;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> foodItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kathi_user_food_cart_view);

        KathiUserFoodListViewx = findViewById(R.id.KathiUserFoodListViewx);



    }
}
