package com.example.dti_project;

import java.util.List;

public class kathiadminfoodhistorymodel {

    private String CustomPKKathiUser;
    private String Enrollno;
    private String Time;
    private String Date;
    private String ConfirmOrder;
    private List<String> orderDetails;
    private int Total;

    public kathiadminfoodhistorymodel(){

    }

    public kathiadminfoodhistorymodel(String CustomPKKathiUser, String Enrollno, String Time, String Date, String ConfirmOrder, List<String> orderDetails, int Total) {
        this.CustomPKKathiUser = CustomPKKathiUser;
        this.Enrollno = Enrollno;
        this.Time = Time;
        this.Date = Date;
        this.ConfirmOrder = ConfirmOrder;
        this.orderDetails = orderDetails;
        this.Total = Total;
    }

    public String getCustomPKKathiUser() {
        return CustomPKKathiUser;
    }

    public void setCustomPKKathiUser(String customPKKathiUser) {
        this.CustomPKKathiUser = customPKKathiUser;
    }

    public String getEnrollNo() {
        return Enrollno;
    }

    public void setEnrollNo(String enrollNo) {
        this.Enrollno = Enrollno;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        this.Time = Time;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        this.Date = Date;
    }

    public String getConfirmOrder() {
        return ConfirmOrder;
    }

    public void setConfirmOrder(String confirmOrder) {
        this.ConfirmOrder = confirmOrder;
    }

    public List<String> getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(List<String> orderDetails) {
        this.orderDetails = orderDetails;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int total) {
        this.Total = Total;
    }
}
