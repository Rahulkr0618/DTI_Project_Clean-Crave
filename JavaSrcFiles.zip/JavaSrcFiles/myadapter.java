package com.example.dti_project;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.icu.text.Transliterator;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Firebase;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class myadapter extends RecyclerView.Adapter<myadapter.myviewholder> {

    ArrayList<model> datalist;

    public myadapter(ArrayList<model> datalist) {
        this.datalist = datalist;
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow,parent,false);
        return new myviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final myviewholder holder, final int position) {
        holder.laundryadminEnrollCnf.setText(datalist.get(position).getLaundryEnrollNo());
        holder.laundryadminBagNoCnf.setText(datalist.get(position).getLaundryBagNo());
        holder.laundryadminTimeCnf.setText(datalist.get(position).getTime());
        holder.laundryadminDateCnf.setText(datalist.get(position).getLaundryDate());
        holder.laundryadminKurtaCnf.setText(datalist.get(position).getLaundryKurta());
        holder.laundryadminPajamaCnf.setText(datalist.get(position).getLaundryPajama());
        holder.laundryadminShirtCnf.setText(datalist.get(position).getLaundryShirt());
        holder.laundryadminTShirtCnf.setText(datalist.get(position).getLaundryTshirt());
        holder.laundryadminPantCnf.setText(datalist.get(position).getLaundryPant());
        holder.laundryadminLowerCnf.setText(datalist.get(position).getLaundryLower());
        holder.laundryadminShortsCnf.setText(datalist.get(position).getLaundryShorts());
        holder.laundryadminBedsheetCnf.setText(datalist.get(position).getLaundryBedsheet());
        holder.laundryadminPillowCovCnf.setText(datalist.get(position).getLaundryPillowCov());
        holder.laundryadminTowelCnf.setText(datalist.get(position).getLaundryTowel());
        holder.laundryadminDuppataCnf.setText(datalist.get(position).getLaundryDuppata());
        holder.laundryadminTotalCnf.setText(datalist.get(position).getLaundryTotal());
        holder.laundryadminConfirmCnf.setText(datalist.get(position).getConfirmation());







        holder.admin_edit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String documentId = datalist.get(position).getCustomPrimaryKey();

                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
                String currentTime = simpleDateFormat.format(calendar.getTime());


                final DialogPlus dialogPlus = DialogPlus.newDialog(holder.laundryadminEnrollCnf.getContext())
                        .setContentHolder(new ViewHolder(R.layout.dialogcontentlaundryadmin))
                        .setExpanded(true,2800)
                        .create();

                View myview = dialogPlus.getHolderView();
                EditText laundryAdminUpdateEnrollNo = myview.findViewById(R.id.laundryAdminUpdateEnrollNo);
                EditText laundryAdminUpdateBagNo = myview.findViewById(R.id.laundryAdminUpdateBagNo);
                EditText laundryAdminUpdateTime = myview.findViewById(R.id.laundryAdminUpdateTime);
                EditText laundryAdminUpdateDate = myview.findViewById(R.id.laundryAdminUpdateDate);
                EditText laundryAdminUpdateConfirm = myview.findViewById(R.id.laundryAdminUpdateConfirm);
                EditText laundryAdminUpdateKurta = myview.findViewById(R.id.laundryAdminUpdateKurta);
                EditText laundryAdminUpdatePajama = myview.findViewById(R.id.laundryAdminUpdatePajama);
                EditText laundryAdminUpdateShirt = myview.findViewById(R.id.laundryAdminUpdateShirt);
                EditText laundryAdminUpdateTShirt = myview.findViewById(R.id.laundryAdminUpdateTShirt);
                EditText laundryAdminUpdatePant = myview.findViewById(R.id.laundryAdminUpdatePant);
                EditText laundryAdminUpdateLower = myview.findViewById(R.id.laundryAdminUpdateLower);
                EditText laundryAdminUpdateShorts = myview.findViewById(R.id.laundryAdminUpdateShorts);
                EditText laundryAdminUpdateBedsheet = myview.findViewById(R.id.laundryAdminUpdateBedsheet);
                EditText laundryAdminUpdateCover = myview.findViewById(R.id.laundryAdminUpdateCover);
                EditText laundryAdminUpdateTowel = myview.findViewById(R.id.laundryAdminUpdateTowel);
                EditText laundryAdminUpdateDuppata = myview.findViewById(R.id.laundryAdminUpdateDuppata);
                EditText laundryAdminUpdateTotal = myview.findViewById(R.id.laundryAdminUpdateTotal);
                Button laundryadminUpdateBtn = myview.findViewById(R.id.laundryadminUpdateBtn);


                laundryAdminUpdateEnrollNo.setText(datalist.get(position).getLaundryEnrollNo());
                laundryAdminUpdateBagNo.setText(datalist.get(position).getLaundryBagNo());
                laundryAdminUpdateTime.setText(currentTime);
                laundryAdminUpdateDate.setText(datalist.get(position).getLaundryDate());
                laundryAdminUpdateConfirm.setText(datalist.get(position).getConfirmation());
                laundryAdminUpdateKurta.setText(datalist.get(position).getLaundryKurta());
                laundryAdminUpdatePajama.setText(datalist.get(position).getLaundryPajama());
                laundryAdminUpdateShirt.setText(datalist.get(position).getLaundryShirt());
                laundryAdminUpdateTShirt.setText(datalist.get(position).getLaundryTshirt());
                laundryAdminUpdatePant.setText(datalist.get(position).getLaundryPant());
                laundryAdminUpdateLower.setText(datalist.get(position).getLaundryLower());
                laundryAdminUpdateShorts.setText(datalist.get(position).getLaundryShorts());
                laundryAdminUpdateBedsheet.setText(datalist.get(position).getLaundryBedsheet());
                laundryAdminUpdateCover.setText(datalist.get(position).getLaundryPillowCov());
                laundryAdminUpdateTowel.setText(datalist.get(position).getLaundryTowel());
                laundryAdminUpdateDuppata.setText(datalist.get(position).getLaundryDuppata());
                laundryAdminUpdateTotal.setText(datalist.get(position).getLaundryTotal());

                dialogPlus.show();


                laundryadminUpdateBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Log.d(TAG, "Update button clicked");

                        DocumentReference docref = FirebaseFirestore.getInstance().collection("LaundryDetail").document(documentId);


                        String updatedEnrollNo = laundryAdminUpdateEnrollNo.getText().toString();
                        String updatedBagNo = laundryAdminUpdateBagNo.getText().toString();
                        String updatedTime = laundryAdminUpdateTime.getText().toString();
                        String updatedDate = laundryAdminUpdateDate.getText().toString();
                        String updatedConfirm = laundryAdminUpdateConfirm.getText().toString();
                        String updatedKurta = laundryAdminUpdateKurta.getText().toString();
                        String updatedPajama = laundryAdminUpdatePajama.getText().toString();
                        String updatedShirt = laundryAdminUpdateShirt.getText().toString();
                        String updatedTShirt = laundryAdminUpdateTShirt.getText().toString();
                        String updatedPant = laundryAdminUpdatePant.getText().toString();
                        String updatedLower = laundryAdminUpdateLower.getText().toString();
                        String updatedShorts = laundryAdminUpdateShorts.getText().toString();
                        String updatedBedsheet = laundryAdminUpdateBedsheet.getText().toString();
                        String updatedCover = laundryAdminUpdateCover.getText().toString();
                        String updatedTowel = laundryAdminUpdateTowel.getText().toString();
                        String updatedDuppata = laundryAdminUpdateDuppata.getText().toString();
                        String updatedTotal = laundryAdminUpdateTotal.getText().toString();


                        Map<String, Object> updates = new HashMap<>();
                        updates.put("laundryEnrollNo", updatedEnrollNo);
                        updates.put("laundryBagNo", updatedBagNo);
                        updates.put("time", updatedTime);
                        updates.put("laundryDate", updatedDate);
                        updates.put("confirmation", updatedConfirm);
                        updates.put("laundryKurta", updatedKurta);
                        updates.put("laundryPajama", updatedPajama);
                        updates.put("laundryShirt", updatedShirt);
                        updates.put("laundryTshirt", updatedTShirt);
                        updates.put("laundryPant", updatedPant);
                        updates.put("laundryLower", updatedLower);
                        updates.put("laundryShorts", updatedShorts);
                        updates.put("laundryBedsheet", updatedBedsheet);
                        updates.put("laundryPillowCov", updatedCover);
                        updates.put("laundryTowel", updatedTowel);
                        updates.put("laundryDuppata", updatedDuppata);
                        updates.put("laundryTotal", updatedTotal);

                        docref.update(updates).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(view.getContext(), "Data updated successfully", Toast.LENGTH_SHORT).show();
                                dialogPlus.dismiss();
                                Log.d(TAG, "Data updated successfully");
                            }

                        })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e(TAG, "Failed to update data", e);
                                        dialogPlus.dismiss();
                                        Toast.makeText(view.getContext(), "Failed to update data", Toast.LENGTH_SHORT).show();
                                    }
                                });

                    }
                });
            }
        });



    }

    @Override
    public int getItemCount() {
        return datalist.size();
    }


    class myviewholder extends RecyclerView.ViewHolder{

            ImageButton admin_edit_btn,admin_delete_btn;
            TextView laundryadminEnrollCnf,laundryadminBagNoCnf,laundryadminTimeCnf,laundryadminDateCnf,
                    laundryadminKurtaCnf,laundryadminPajamaCnf,laundryadminShirtCnf,laundryadminTShirtCnf,
                    laundryadminPantCnf,laundryadminLowerCnf,laundryadminShortsCnf,laundryadminBedsheetCnf,
                    laundryadminPillowCovCnf,laundryadminTowelCnf,laundryadminDuppataCnf,laundryadminTotalCnf,
                    laundryadminConfirmCnf;
            public myviewholder(@NonNull View itemView){
                super(itemView);

                laundryadminEnrollCnf = (TextView) itemView.findViewById(R.id.laundryadminEnrollCnf);
                laundryadminBagNoCnf = (TextView) itemView.findViewById(R.id.laundryadminBagNoCnf);
                laundryadminTimeCnf = (TextView) itemView.findViewById(R.id.laundryadminTimeCnf);
                laundryadminDateCnf = (TextView) itemView.findViewById(R.id.laundryadminDateCnf);
                laundryadminKurtaCnf = (TextView) itemView.findViewById(R.id.laundryadminKurtaCnf);
                laundryadminPajamaCnf = (TextView) itemView.findViewById(R.id.laundryadminPajamaCnf);
                laundryadminShirtCnf = (TextView) itemView.findViewById(R.id.laundryadminShirtCnf);
                laundryadminTShirtCnf = (TextView) itemView.findViewById(R.id.laundryadminTShirtCnf);
                laundryadminPantCnf = (TextView) itemView.findViewById(R.id.laundryadminPantCnf);
                laundryadminLowerCnf = (TextView) itemView.findViewById(R.id.laundryadminLowerCnf);
                laundryadminShortsCnf = (TextView) itemView.findViewById(R.id.laundryadminShortsCnf);
                laundryadminBedsheetCnf = (TextView) itemView.findViewById(R.id.laundryadminBedsheetCnf);
                laundryadminPillowCovCnf = (TextView) itemView.findViewById(R.id.laundryadminPillowCovCnf);
                laundryadminTowelCnf = (TextView) itemView.findViewById(R.id.laundryadminTowelCnf);
                laundryadminDuppataCnf = (TextView) itemView.findViewById(R.id.laundryadminDuppataCnf);
                laundryadminTotalCnf = (TextView) itemView.findViewById(R.id.laundryadminTotalCnf);
                laundryadminConfirmCnf = (TextView) itemView.findViewById(R.id.laundryadminConfirmCnf);
                //admin_delete_btn = (ImageButton) itemView.findViewById(R.id.admin_delete_btn);
                admin_edit_btn = (ImageButton) itemView.findViewById(R.id.admin_edit_btn);


            }
        }



}
