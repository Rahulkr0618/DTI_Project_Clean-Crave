package com.example.dti_project;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Query;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class KathiHomePage extends AppCompatActivity {

    ListView listviewkathiusercart;

    RecyclerView KathiUserRecView;
    Button KathiUserFoodOrderBtn;
    ArrayList<KathiUserFoodModel> KathiUserFoodList;
    EditText KathiUserSearchFood;
    TextView kathihomepageuseridfoodorder;

    FirebaseFirestore KathiUserDB;

    KathiUserFoodMenuAdapter KathiUserFoodMenuAdapterObj;

    @Override
    public void onBackPressed() {

        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kathi_home_page);

        listviewkathiusercart = (ListView) findViewById(R.id.listviewkathiusercart);

        KathiUserRecView = (RecyclerView) findViewById(R.id.KathiUserRecView);
        KathiUserRecView.setLayoutManager(new LinearLayoutManager(this));

        KathiUserSearchFood = (EditText)findViewById(R.id.KathiUserSearchFood);
        KathiUserFoodOrderBtn = (Button)findViewById(R.id.KathiUserFoodOrderBtn);
        kathihomepageuseridfoodorder = (TextView)findViewById(R.id.kathihomepageuseridfoodorder);
        String userEmail = getIntent().getStringExtra("userEmail");

        kathihomepageuseridfoodorder.setText(userEmail);

        KathiUserFoodList = new ArrayList<>();
        KathiUserFoodMenuAdapterObj = new KathiUserFoodMenuAdapter(KathiUserFoodList);
        KathiUserRecView.setAdapter(KathiUserFoodMenuAdapterObj);


        KathiUserDB = FirebaseFirestore.getInstance();


        KathiUserDB.collection("FoodMenu").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (DocumentSnapshot document : queryDocumentSnapshots) {
                            KathiUserFoodModel obj = document.toObject(KathiUserFoodModel.class);
                            if (obj != null && obj.getStock() != null && obj.getStock().equalsIgnoreCase("yes")) {
                                KathiUserFoodList.add(obj);
                            }
                        }
                        KathiUserFoodMenuAdapterObj.notifyDataSetChanged();
                    }
                })
                .addOnFailureListener(e -> Log.e(TAG, "Error fetching data: ", e));


        KathiUserSearchFood.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String searchText = charSequence.toString();
                searchData(searchText);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        KathiUserFoodOrderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                List<OrderedItem> orderedItems = new ArrayList<>();

                for (int i = 0; i < listviewkathiusercart.getCount(); i++) {
                    View listItem = listviewkathiusercart.getChildAt(i);
                    if (listItem != null) {
                        TextView itemNameView = listItem.findViewById(R.id.item_name);
                        TextView itemQuantityView = listItem.findViewById(R.id.item_quantity);
                        TextView itemPriceView = listItem.findViewById(R.id.item_price);

                        String itemName = itemNameView.getText().toString();
                        int itemQuantity = Integer.parseInt(itemQuantityView.getText().toString());
                        int itemPrice = Integer.parseInt(itemPriceView.getText().toString());

                        // Create OrderedItem object and add it to the list
                        orderedItems.add(new OrderedItem(itemName, itemQuantity, itemPrice));
                    }
                }

                saveOrderToFirestore(orderedItems);

            }
        });

    }

    private void saveOrderToFirestore(List<OrderedItem> orderedItems) {
        String userEmail = getIntent().getStringExtra("userEmail");

        int totalPriceForItems = calculateTotalPrice(orderedItems);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss", Locale.getDefault());
        String dateTime = dateFormat.format(new Date());

        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
        String ordertime = timeFormat.format(new Date());

        SimpleDateFormat dateorderFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        String orderFoodDate = dateorderFormat.format(new Date());

        String documentKey = userEmail + "_" + dateTime;

        List<String> orderDetailsList = new ArrayList<>();

        // Populate the orderDetailsList with formatted item names and quantities
        for (OrderedItem item : orderedItems) {
            String formattedItem = item.getItemName() + " qtn-" + item.getQuantity();
            orderDetailsList.add(formattedItem);
        }

        HashMap<String, Object> orderMap = new HashMap<>();
        orderMap.put("CustomPKKathiUser", documentKey);
        orderMap.put("Enrollno", userEmail);
        orderMap.put("Time", ordertime);
        orderMap.put("Date", orderFoodDate);
        orderMap.put("ConfirmOrder", "no");
        orderMap.put("orderDetails", orderDetailsList);
        orderMap.put("Total", totalPriceForItems); // Update to totalPriceForItems

        KathiUserDB.collection("KathiFoodOrder")
                .document(documentKey) // Use custom document key
                .set(orderMap)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Order saved to Firestore with key: " + documentKey);
                    Toast.makeText(this, "Order Placed Successfully...", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error saving order to Firestore", e);
                });
    }

    private int calculateTotalPrice(List<OrderedItem> orderedItems) {
        int totalPrice = 0;

        for (OrderedItem item : orderedItems) {
            totalPrice += item.getPrice() * item.getQuantity();
        }
        return totalPrice;
    }

    private void searchData(String searchText) {
        Query query;

        if (!TextUtils.isEmpty(searchText)) {

            Log.d(TAG, "Search Text: " + searchText);

            query = KathiUserDB.collection("FoodMenu")
                    .orderBy("Name")
                    .startAt(searchText)
                    .endAt(searchText + "\uf8ff")
                    .whereEqualTo("Stock", "yes");
        } else {
            loadOriginalData();
            return;
        }

        query.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    KathiUserFoodList.clear();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        KathiUserFoodModel obj = document.toObject(KathiUserFoodModel.class);
                        KathiUserFoodList.add(obj);
                    }
                    KathiUserFoodMenuAdapterObj.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> Log.e(TAG, "Error searching data: ", e));
    }

    private void loadOriginalData() {
        KathiUserDB.collection("FoodMenu").get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    KathiUserFoodList.clear();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        KathiUserFoodModel obj = document.toObject(KathiUserFoodModel.class);
                        if (obj != null && obj.getStock() != null && obj.getStock().equalsIgnoreCase("yes")) {
                            KathiUserFoodList.add(obj);
                        }
                    }
                    KathiUserFoodMenuAdapterObj.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> Log.e(TAG, "Error fetching data: ", e));
    }

}
