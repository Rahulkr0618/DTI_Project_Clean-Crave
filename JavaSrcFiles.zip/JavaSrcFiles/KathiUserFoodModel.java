package com.example.dti_project;

public class KathiUserFoodModel {

    String Image,Name,PID,Price,Stock,CustomPKKathi;

    public KathiUserFoodModel(){

    }

    public KathiUserFoodModel(String CustomPKKathi,String Image, String Name, String PID, String Price, String Stock) {
        this.CustomPKKathi = CustomPKKathi;
        this.Image = Image;
        this.Name = Name;
        this.PID = PID;
        this.Price = Price;
        this.Stock = Stock;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPID() {
        return PID;
    }

    public void setPID(String PID) {
        this.PID = PID;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getStock() {
        return Stock;
    }

    public void setStock(String stock) {
        Stock = stock;
    }

    public String getCustomPKKathi() {
        return CustomPKKathi;
    }

    public void setCustomPKKathi(String customPKKathi) {
        CustomPKKathi = customPKKathi;
    }
}
