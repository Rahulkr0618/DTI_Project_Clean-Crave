package com.example.dti_project;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LaundryAdminCnfPage extends AppCompatActivity {

    RecyclerView recview;
    EditText admin_Search_BagNo,admin_Search_Date;
    myadapter adapter;
    ArrayList<model> datalist;
    FirebaseFirestore databaseRef;


    @Override
    public void onBackPressed() {

        Intent intent = new Intent(this, LaundryAdminPage.class);
        startActivity(intent);
        finish();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laundry_admin_cnf_page);

        admin_Search_Date = (EditText) findViewById(R.id.admin_Search_Date);
        admin_Search_BagNo = (EditText) findViewById(R.id.admin_Search_BagNo);

        recview = (RecyclerView) findViewById(R.id.recview);
        recview.setLayoutManager(new LinearLayoutManager(this));
        datalist = new ArrayList<>();
        adapter = new myadapter(datalist);
        recview.setAdapter(adapter);

        databaseRef = FirebaseFirestore.getInstance();

        loadData();

        admin_Search_BagNo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchData(admin_Search_BagNo.getText().toString(), admin_Search_Date.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        admin_Search_Date.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchData(admin_Search_BagNo.getText().toString(), admin_Search_Date.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }


//        databaseRef.collection("LaundryDetail").get()
//                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
//                    @Override
//                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
//                        List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
//                        for(DocumentSnapshot d:list){
//                            model obj = d.toObject(model.class);
//                            datalist.add(obj);
//                        }
//                        adapter.notifyDataSetChanged();
//                    }
//                });


    private void loadData() {
        databaseRef.collection("LaundryDetail")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    datalist.clear();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        model obj = document.toObject(model.class);
                        datalist.add(obj);
                    }
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> Log.e(TAG, "Error fetching data: ", e));
    }

    private void searchData(String bagNo, String date) {
        Query query;

        if (!TextUtils.isEmpty(bagNo) && !TextUtils.isEmpty(date)) {
            query = databaseRef.collection("LaundryDetail")
                    .whereEqualTo("laundryBagNo", bagNo)
                    .whereEqualTo("laundryDate", date);
        } else if (!TextUtils.isEmpty(bagNo)) {
            query = databaseRef.collection("LaundryDetail")
                    .whereEqualTo("laundryBagNo", bagNo);
        } else if (!TextUtils.isEmpty(date)) {
            query = databaseRef.collection("LaundryDetail")
                    .whereEqualTo("laundryDate", date);
        } else {
            loadData();
            return;
        }

        query.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    datalist.clear();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        model obj = document.toObject(model.class);
                        datalist.add(obj);
                    }
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> Log.e(TAG, "Error searching data: ", e));
    }


}
