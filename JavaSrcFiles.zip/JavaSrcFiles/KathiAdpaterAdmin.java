package com.example.dti_project;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class KathiAdpaterAdmin extends RecyclerView.Adapter<KathiAdpaterAdmin.myviewhholderkathiadminupd>{

    ArrayList<Kathimodel> kathifoodlist;

    FirebaseFirestore KathiAdminFoodDB;

    FirebaseFirestore FBFAdmindb = FirebaseFirestore.getInstance();

    public KathiAdpaterAdmin(ArrayList<Kathimodel> kathifoodlist) {
        this.kathifoodlist = kathifoodlist;
    }

    @NonNull
    @Override
    public myviewhholderkathiadminupd onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.kathiadminsinglerow,parent,false);
        return new myviewhholderkathiadminupd(view1);
    }

    @Override
    public void onBindViewHolder(@NonNull final myviewhholderkathiadminupd holder, final int position) {

        Kathimodel currentItem = kathifoodlist.get(position);

        holder.foodid.setText(currentItem.getPID());
        holder.foodname.setText(currentItem.getName());
        holder.foodprice.setText(currentItem.getPrice());
        holder.foodstock.setText(currentItem.getStock());

        Glide.with(holder.foodimg.getContext()).load(currentItem.getImage()).into(holder.foodimg);

        holder.kathiadminupdatefoodbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final DialogPlus dialogPlus = DialogPlus.newDialog(holder.foodid.getContext())
                        .setContentHolder(new ViewHolder(R.layout.dialogcontentkathiadminupdatefood))
                        .setExpanded(true,2000)
                        .create();



                View myview1 = dialogPlus.getHolderView();

                EditText kathiadmin_dialog_update_foodimg = myview1.findViewById(R.id.kathiadmin_dialog_update_foodimg);
                EditText kathiadmin_dialog_update_foodID = myview1.findViewById(R.id.kathiadmin_dialog_update_foodID);
                EditText kathiadmin_dialog_update_foodname = myview1.findViewById(R.id.kathiadmin_dialog_update_foodname);
                EditText kathiadmin_dialog_update_foodprice = myview1.findViewById(R.id.kathiadmin_dialog_update_foodprice);
                EditText kathiadmin_dialog_update_foodstock = myview1.findViewById(R.id.kathiadmin_dialog_update_foodstock);
                Button kathiadmin_dialog_update_updatebtn = myview1.findViewById(R.id.kathiadmin_dialog_update_updatebtn);

                kathiadmin_dialog_update_foodimg.setText(kathifoodlist.get(position).getImage());
                kathiadmin_dialog_update_foodID.setText(kathifoodlist.get(position).getPID());
                kathiadmin_dialog_update_foodname.setText(kathifoodlist.get(position).getName());
                kathiadmin_dialog_update_foodprice.setText(kathifoodlist.get(position).getPrice());
                kathiadmin_dialog_update_foodstock.setText(kathifoodlist.get(position).getStock());


                dialogPlus.show();

                kathiadmin_dialog_update_updatebtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Log.d(TAG, "Update button clicked");

                        String documentid = kathifoodlist.get(position).getCustomPKKathi();

                        DocumentReference KathiAdminFoodDB = FirebaseFirestore.getInstance().collection("FoodMenu").document(documentid);

                        String UpdatedFoodURLImage = kathiadmin_dialog_update_foodimg.getText().toString();
                        String UpdatedFoodID = kathiadmin_dialog_update_foodID.getText().toString();
                        String UpdatedFoodName = kathiadmin_dialog_update_foodname.getText().toString();
                        String UpdatedFoodPrice = kathiadmin_dialog_update_foodprice.getText().toString();
                        String UpdatedFoodStock = kathiadmin_dialog_update_foodstock.getText().toString();

                        Map<String, Object> updateskathiadminfoodupdate = new HashMap<>();
                        updateskathiadminfoodupdate.put("Image",UpdatedFoodURLImage);
                        updateskathiadminfoodupdate.put("PID",UpdatedFoodID);
                        updateskathiadminfoodupdate.put("Name",UpdatedFoodName);
                        updateskathiadminfoodupdate.put("Price",UpdatedFoodPrice);
                        updateskathiadminfoodupdate.put("Stock",UpdatedFoodStock);


                        KathiAdminFoodDB.update(updateskathiadminfoodupdate).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                // Fetch the updated data again from the database
                                FBFAdmindb.collection("FoodMenu").get()
                                        .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                            @Override
                                            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                                kathifoodlist.clear();
                                                for (DocumentSnapshot document : queryDocumentSnapshots) {
                                                    Kathimodel model = document.toObject(Kathimodel.class);
                                                    kathifoodlist.add(model); // Add the updated data
                                                }
                                                notifyDataSetChanged();
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Log.e(TAG, "Error fetching updated data: ", e);
                                            }
                                        });

                                Toast.makeText(view.getContext(), "Data updated successfully", Toast.LENGTH_SHORT).show();
                                dialogPlus.dismiss();
                                Log.d(TAG, "Data updated successfully");
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e(TAG, "Failed to update data", e);
                                dialogPlus.dismiss();
                                Toast.makeText(view.getContext(), "Failed to update data", Toast.LENGTH_SHORT).show();
                            }
                        });





//                        KathiAdminFoodDB.update(updateskathiadminfoodupdate).addOnSuccessListener(new OnSuccessListener<Void>() {
//                            @Override
//                            public void onSuccess(Void unused) {
//
//                                Toast.makeText(view.getContext(), "Data updated successfully", Toast.LENGTH_SHORT).show();
//                                dialogPlus.dismiss();
//                                Log.d(TAG, "Data updated successfully");
//                            }
//                        }).addOnFailureListener(new OnFailureListener() {
//                            @Override
//                            public void onFailure(@NonNull Exception e) {
//                                Log.e(TAG, "Failed to update data", e);
//                                dialogPlus.dismiss();
//                                Toast.makeText(view.getContext(), "Failed to update data", Toast.LENGTH_SHORT).show();
//                            }
//                        });

                    }
                });

            }
        });



    }

    @Override
    public int getItemCount() {
        return kathifoodlist.size();
    }

    class myviewhholderkathiadminupd extends RecyclerView.ViewHolder {

        Button kathiadminupdatefoodbtn;
        ImageView foodimg;
        TextView foodid,foodname,foodprice,foodstock;

        public myviewhholderkathiadminupd(@NonNull View itemView) {
            super(itemView);

            foodid = (TextView) itemView.findViewById(R.id.kathiadmin_PID);
            foodname = (TextView) itemView.findViewById(R.id.kathiadmin_FoodName);
            foodprice = (TextView) itemView.findViewById(R.id.kathiadmin_FoodPrice);
            foodstock = (TextView) itemView.findViewById(R.id.kathiadmin_FoodStock);
            foodimg = (ImageView) itemView.findViewById(R.id.kathiadmin_food_img);
            kathiadminupdatefoodbtn = (Button) itemView.findViewById(R.id.kathiadminupdatefoodbtn);


        }
    }

}
