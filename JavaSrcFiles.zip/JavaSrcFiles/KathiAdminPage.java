package com.example.dti_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import android.os.Handler;

public class KathiAdminPage extends AppCompatActivity {

    ImageButton Add_Food_Btn,update_Food_Btn,kathiadminfoodorderhistory;
    private boolean doubleBackToExitPressedOnce = false;
    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kathi_admin_page);

        Add_Food_Btn = findViewById(R.id.Add_Food_Btn);
        update_Food_Btn = findViewById(R.id.update_Food_Btn);
        kathiadminfoodorderhistory = findViewById(R.id.kathiadminfoodorderhistory);

        Add_Food_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(KathiAdminPage.this, KathiAdminAddFood.class);

                startActivity(intent);
                finish();

            }
        });

        update_Food_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(KathiAdminPage.this, KathiAdminUpdateFood.class);

                startActivity(intent);
                finish();
            }
        });

        kathiadminfoodorderhistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(KathiAdminPage.this, KathiAdminFoodOrderHistoryPage.class);

                startActivity(intent);
                finish();

            }
        });



    }
}