package com.example.dti_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class KathiAdminAddFood extends AppCompatActivity {

    EditText admin_Add_Food_ID,Admin_Add_Food_Image_URL,admin_Add_Food_Name,admin_Add_Food_Price,admin_Add_Food_Stock;
    Button Add_Food_Btn;

    FirebaseFirestore db;



    @Override
    public void onBackPressed() {

        Intent intent = new Intent(this, KathiAdminPage.class);
        startActivity(intent);
        finish();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kathi_admin_add_food);

        db = FirebaseFirestore.getInstance();

        Add_Food_Btn = findViewById(R.id.Add_Food_Btn);
        admin_Add_Food_ID = findViewById(R.id.admin_Add_Food_ID);
        Admin_Add_Food_Image_URL = findViewById(R.id.Admin_Add_Food_Image_URL);
        admin_Add_Food_Name = findViewById(R.id.admin_Add_Food_Name);
        admin_Add_Food_Price = findViewById(R.id.admin_Add_Food_Price);
        admin_Add_Food_Stock = findViewById(R.id.admin_Add_Food_Stock);


        Add_Food_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String CustomPkKathi = generateCustomPrimaryKey();
                String Food_ID = admin_Add_Food_ID.getText().toString();
                String Food_Img_URL =  Admin_Add_Food_Image_URL.getText().toString();
                String Food_Name =  admin_Add_Food_Name.getText().toString();
                String Food_Price =  admin_Add_Food_Price.getText().toString();
                String Food_Stock =  admin_Add_Food_Stock.getText().toString();


                Map<String, Object> fooditem = new HashMap<>();
                fooditem.put("CustomPKKathi",CustomPkKathi);
                fooditem.put("PID", Food_ID);
                fooditem.put("Image", Food_Img_URL);
                fooditem.put("Name", Food_Name);
                fooditem.put("Price", Food_Price);
                fooditem.put("Stock", Food_Stock);

                db.collection("FoodMenu")
                        .document(CustomPkKathi)
                        .set(fooditem)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(KathiAdminAddFood.this, "Food Item added successfully", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(KathiAdminAddFood.this, "Failed to add Food details: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });


            }
        });

    }

    private String generateCustomPrimaryKey() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
        String currentDateandTime = sdf.format(new Date());
        return currentDateandTime;
    }

}